# Pokemon API and Wikipedia Test Suite

En el proyecto contiene pruebas automatizadas para la PokeApi y Wikipedia usando Playwright con TypeScript.

## Prerequisitos

- Node.js 
- npm

## Instalacion

1. clonar el repositorio
2. Navegar por el directorio del proyecto
3. Instalar las dependencias:

```bash
npm install

npm playwright test 

npx playwright show-report